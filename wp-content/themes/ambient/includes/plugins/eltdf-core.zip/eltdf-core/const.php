<?php

define('ELATED_CORE_VERSION', '1.3');
define('ELATED_CORE_ABS_PATH', dirname(__FILE__));
define('ELATED_CORE_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('ELATED_CORE_CPT_PATH', ELATED_CORE_ABS_PATH.'/post-types');
define('ELATED_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );
define('ELATED_CORE_OPTIONS_NAME', 'eltd_options_ambient' );